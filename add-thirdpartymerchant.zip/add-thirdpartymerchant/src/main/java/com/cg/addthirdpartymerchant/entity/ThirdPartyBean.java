package com.cg.addthirdpartymerchant.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "merchants")
public class ThirdPartyBean implements Serializable
{

	@Id
	private long id;
	@Column(name = "mer_name")
	private String mname;
	@Column(name = "mer_num")
	private long mmobile;
	@Column(name = "mer_mail")
	private String mmail;
	@Column(name = "mer_add")
	private String maddress;

	public ThirdPartyBean(long id, String mname, long mmobile, String mmail, String maddress) 
	{
		super();
		this.id = id;
		this.mname = mname;
		this.mmobile = mmobile;
		this.mmail = mmail;
		this.maddress = maddress;
	}

	public ThirdPartyBean() {
		super();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public long getMmobile() {
		return mmobile;
	}

	public void setMmobile(long mmobile) {
		this.mmobile = mmobile;
	}

	public String getMmail() {
		return mmail;
	}

	public void setMmail(String mmail) {
		this.mmail = mmail;
	}

	public String getMaddress() {
		return maddress;
	}

	public void setMaddress(String maddress) {
		this.maddress = maddress;
	}

	@Override
	public String toString() {
		return "Merchant [id=" + id + ", mname=" + mname + ", mmobile=" + mmobile + ", mmail=" + mmail + ", maddress="
				+ maddress + "]";
	}
}
