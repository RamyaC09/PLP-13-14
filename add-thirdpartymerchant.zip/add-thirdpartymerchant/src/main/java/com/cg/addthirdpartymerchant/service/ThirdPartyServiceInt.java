package com.cg.addthirdpartymerchant.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.cg.addthirdpartymerchant.entity.ProductsBean;
import com.cg.addthirdpartymerchant.entity.ThirdPartyBean;

public interface ThirdPartyServiceInt
{

	void deleteProduct(int productId);

	List<ProductsBean> createProduct(ProductsBean merchant);

	Optional<ThirdPartyBean> getProductByMid(long id);

	//List<ThirdPartyBean> getAllMerchants();

}
