package com.cg.addthirdpartymerchant.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.addthirdpartymerchant.entity.ProductsBean;

@Repository
public interface ThirdPartyProdDaoInt extends JpaRepository<ProductsBean, Integer>
{

}
