package com.cg.addthirdpartymerchant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AddThirdpartymerchantApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddThirdpartymerchantApplication.class, args);
	}

}
