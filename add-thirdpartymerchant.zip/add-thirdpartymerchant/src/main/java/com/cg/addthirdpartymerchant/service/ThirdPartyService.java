package com.cg.addthirdpartymerchant.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.addthirdpartymerchant.dao.ThirdPartyDaoInt;
import com.cg.addthirdpartymerchant.dao.ThirdPartyProdDaoInt;
import com.cg.addthirdpartymerchant.entity.ProductsBean;
import com.cg.addthirdpartymerchant.entity.ThirdPartyBean;

@Service
public class ThirdPartyService implements ThirdPartyServiceInt
{
	@Autowired
	ThirdPartyProdDaoInt thirdPartyProdDaoInt;

	ThirdPartyDaoInt thirdPartyDaoInt;
	
	@Override
	public List<ProductsBean> createProduct(ProductsBean merchant)
	{
		thirdPartyProdDaoInt.save(merchant);
		return thirdPartyProdDaoInt.findAll();
	}

	/*@Override
	public List<ThirdPartyBean> getAllMerchants()
	{


		return null;
	}*/

	@Override
	public void deleteProduct(int productId) 
	{
		thirdPartyProdDaoInt.deleteById(productId);
		
	}

	@Override
	public Optional<ThirdPartyBean> getProductByMid(long id) 
	{
		return thirdPartyDaoInt.findById(id);
	}
	
	

}
