package com.cg.addthirdpartymerchant.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.addthirdpartymerchant.entity.ProductsBean;
import com.cg.addthirdpartymerchant.entity.ThirdPartyBean;
import com.cg.addthirdpartymerchant.service.ThirdPartyServiceInt;

@RestController
public class ThirdPartyController 
{
	@Autowired
	ThirdPartyServiceInt thirdPartyServiceInt;
	
	/*@RequestMapping("/getdetails")
	public List<ThirdPartyBean> getAllProducts() 
	{
		return thirdPartyServiceInt.getAllMerchants();
	}*/
	
	@RequestMapping(value="/adddetails", method=RequestMethod.POST)
	public List<ProductsBean> thirdparty(@RequestBody ProductsBean merchant) 
	{
		return thirdPartyServiceInt.createProduct(merchant);
	}
	
	@DeleteMapping(value = "/products/{productId}")
	public ResponseEntity<String> deleteProduct(@PathVariable int productId)
	{
		thirdPartyServiceInt.deleteProduct(productId);
		return new ResponseEntity<String>("Merchant with id " + productId + " deleted", HttpStatus.OK);
	}
	
	@RequestMapping(value="/detailsbyid/{id}", method=RequestMethod.GET)
	public Optional<ThirdPartyBean> getProductById(@PathVariable int id)
	{
		return thirdPartyServiceInt.getProductByMid(id);
    }
	
	
	
//	
//	@RequestMapping(value="/addmerchant", method=RequestMethod.POST)
//	public List<ThirdPartyBean> addThirdPartyMerchant(@RequestBody ThirdPartyBean thirdPartyBean)
//	{
//		return thirdPartyServiceInt.addThirdParty(thirdPartyBean);
//	}
}
