package com.cg.addthirdpartymerchant.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.addthirdpartymerchant.entity.ThirdPartyBean;

@Repository
public interface ThirdPartyDaoInt extends JpaRepository<ThirdPartyBean, Long>
{

}
