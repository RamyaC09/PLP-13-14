package com.cg.addthirdpartymerchant.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class ProductsBean 
{
	//private static final long serialVersionUID = 1L;
	@Id
	private int productId;
	private String productName;
	private String description;
	private double price;
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "ProductsBean [productId=" + productId + ", productName=" + productName
				+ ", description=" + description + ", price=" + price + "]";
	}
	
	
	
}
