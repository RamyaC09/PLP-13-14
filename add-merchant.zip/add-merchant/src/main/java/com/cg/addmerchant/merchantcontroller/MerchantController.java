package com.cg.addmerchant.merchantcontroller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.addmerchant.merchantentity.MerchantBean;
import com.cg.addmerchant.merchantservice.MerchantServiceInterface;

@RestController
public class MerchantController
{
	@Autowired
	MerchantServiceInterface merchantServiceInterface;
	
	@GetMapping(value = "/showmerchant/{id}")
	public Optional<MerchantBean> showMerchant(@PathVariable long id)
	{
		Optional<MerchantBean> merchantbean = merchantServiceInterface.showMerchant(id);
		return merchantbean;
	}
	
	@RequestMapping(value="/addmerchant", method=RequestMethod.POST)
	public List<MerchantBean> addMerchant(@RequestBody MerchantBean merchantBean)
	{
		return merchantServiceInterface.addMerchant(merchantBean);
	}
	
	@DeleteMapping(value = "/deletemerchant/{id}")
	public ResponseEntity<String> deleteMerchant(@PathVariable long id) 
	{
		merchantServiceInterface.deleteMerchant(id);
		return new ResponseEntity<String>("Merchant with id " + id + " deleted", HttpStatus.OK);
	}
}
