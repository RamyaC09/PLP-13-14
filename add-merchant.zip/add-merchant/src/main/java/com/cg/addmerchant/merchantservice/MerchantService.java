package com.cg.addmerchant.merchantservice;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.addmerchant.merchantdao.MerchantDaoInterface;
import com.cg.addmerchant.merchantentity.MerchantBean;

@Service
public class MerchantService implements MerchantServiceInterface {
	@Autowired
	MerchantDaoInterface merchantDaoInterface;

	@Override
	public List<MerchantBean> addMerchant(MerchantBean merchantBean) {
		merchantDaoInterface.save(merchantBean);
		return merchantDaoInterface.findAll();
	}

	@Override
	public Optional<MerchantBean> showMerchant(long id) {
		return merchantDaoInterface.findById(id);

	}

	@Override
	public void deleteMerchant(long id) {

		merchantDaoInterface.deleteById(id);
	}
}
