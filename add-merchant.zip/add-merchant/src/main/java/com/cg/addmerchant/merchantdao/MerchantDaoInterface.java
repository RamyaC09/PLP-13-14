package com.cg.addmerchant.merchantdao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.addmerchant.merchantentity.MerchantBean;

@Repository
public interface MerchantDaoInterface extends JpaRepository<MerchantBean, Long>
{
	
}
