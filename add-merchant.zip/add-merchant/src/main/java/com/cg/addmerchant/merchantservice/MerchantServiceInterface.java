package com.cg.addmerchant.merchantservice;

import java.util.List;
import java.util.Optional;

import com.cg.addmerchant.merchantentity.MerchantBean;

public interface MerchantServiceInterface {

	List<MerchantBean> addMerchant(MerchantBean merchantBean);

	Optional<MerchantBean> showMerchant(long id);

	void deleteMerchant(long id);

}
